#! /bin/sh -f 

module load MATLAB/2023a-bdist
read -p "Enter grid set name: " job
read -p "Enter job id: " id

structure_file="structure_list.dat"
while read -r structure
do
    echo $structure
    mkdir ${structure}/make_loaded_cube_${job}_${id}_sym
    rm ${structure}/make_loaded_cube_${job}_${id}_sym/*.m
    
    cp make_loaded_cube/* ${structure}/make_loaded_cube_${job}_${id}_sym
    cp ${structure}/loaded_${job}_${id}/VTK/System_0/DensityProfile_Li.vtk ${structure}/make_loaded_cube_${job}_${id}_sym/
    cp ${structure}/make_raspa_cube_${job}/syminfo.cube ${structure}/make_loaded_cube_${job}_${id}_sym/
    cd ${structure}/make_loaded_cube_${job}_${id}_sym/    
    rm slurm*
    sbatch run_matlab_sym.sh
    cd ../../

done < "$structure_file"
