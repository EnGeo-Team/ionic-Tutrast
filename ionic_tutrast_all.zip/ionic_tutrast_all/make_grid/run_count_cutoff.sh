#! /bin/sh -f                                                                                             
#SBATCH -n 1                      
#SBATCH --time 00:05:00                
#SBATCH --job-name=count_cutoff
#SBATCH -A SOME_PROJECT
                                
matlab -nodesktop -nojvm -r count_cutoff
