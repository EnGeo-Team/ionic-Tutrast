#! /bin/sh -f 

module load MATLAB/2023a-bdist
read -p "Enter grid set name: " job
read -p "Enter job id: " id

structure_file="structure_list.dat"
while read -r structure
do
    echo $structure
    mkdir ${structure}/make_loaded_cube_${job}_q${id}
    rm ${structure}/make_loaded_cube_${job}_q${id}/*.m
    
    cp make_loaded_cube/* ${structure}/make_loaded_cube_${job}_q${id}
    cp ${structure}/make_raspa_cube_${job}/supercell.dat ${structure}/make_loaded_cube_${job}_q${id}/
    cp ${structure}/loaded_${job}_q${id}/VTK/System_0/DensityProfile_Li.vtk ${structure}/make_loaded_cube_${job}_q${id}/

    cd ${structure}/make_loaded_cube_${job}_q${id}/    
    rm slurm*
    sbatch run_matlab.sh
    cd ../../

done < "$structure_file"
