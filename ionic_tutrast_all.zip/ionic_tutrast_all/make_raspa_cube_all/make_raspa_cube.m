close all
clear all
%%%user defined%%%%%
E_unit=4;
ngrid_coarse=[1 1 1];
grid_size_raspa=[0.2 0.2 0.2];
LJ_cutoff=12.5;

%%%read grid data%%%%%
disp('writing pot data...')

%Natoms=cube.data(1,1);
if E_unit==1 %kJ/mol
    conv=1;
elseif E_unit==2 %kcal/mol
    conv=4.184;
elseif E_unit==3 %Ry
    conv=1312.7497;
elseif E_unit==4 %eV
    conv=96.4853;
elseif E_unit==5 %Hartree
    conv=627.5096;
end
cube=importdata('grid_UC.cube');
Natoms=cube.data(1,1);
pot_data=cube.data(2*Natoms+5:end,1)*conv;
pot_data(pot_data==Inf)=100000
angles=load('angles.dat');
natoms=cube.data(1,1);
atoms=cube.data(5:2:5+2*natoms-1,1);
nLi_UC=load('nLi_UC.dat');

ngrid=[cube.data(2,1) cube.data(3,1) cube.data(4,1)];
cell_data=cube.data(2:4,2:4);

cell_vector_UC=[ngrid(1)*cell_data(1,:);ngrid(2)*cell_data(2,:);ngrid(3)*cell_data(3,:)]./1.8897259886
supercell=ceil(2*LJ_cutoff./[cell_vector_UC(1,1) cell_vector_UC(2,2) cell_vector_UC(3,3)])
ngrid_SC=ngrid.*supercell;
cell_vector_SC=cell_vector_UC.*supercell'
nLi_tot=nLi_UC*supercell(1)*supercell(2)*supercell(3)
vtk_grid=max(ngrid_SC)


SC_file=fopen('supercell.dat','w');
fprintf(SC_file,'%d %8d %8d',   supercell);
fclose(SC_file);

nLi_file=fopen('nLi_SC.dat','w');
fprintf(nLi_file,'%d',   nLi_tot);
fclose(nLi_file);

vtk_file=fopen('vtk_grid.dat','w');                                                                                                                                                       
fprintf(vtk_file,'%d',vtk_grid);                                                                                                                                                          
fclose(vtk_file);

a=sqrt(cell_vector_UC(1,1).^2+cell_vector_UC(1,2).^2+cell_vector_UC(1,3).^2);
b=sqrt(cell_vector_UC(2,1).^2+cell_vector_UC(2,2).^2+cell_vector_UC(2,3).^2);
c=sqrt(cell_vector_UC(3,1).^2+cell_vector_UC(3,2).^2+cell_vector_UC(3,3).^2);
A=a*supercell(1); B=b*supercell(2); C=c*supercell(3);

format long
abc_file=fopen('abc.dat','w');                                                                                                                                                       
fprintf(abc_file,'%f %18f %18f',A,B,C);                                                                                                                                                          
fclose(abc_file);
format short
%grid_size=[A B C]./ngrid;

%%%% make cif file
cif_file=fopen('grid.cif','w');
fprintf(cif_file,'%s\n','#=====================');
fprintf(cif_file,'%s\n',' ');
fprintf(cif_file,'%s\n','#CRYSTAL DATA');
fprintf(cif_file,'%s\n',' ');
fprintf(cif_file,'%s\n','#---------------------');
fprintf(cif_file,'%s\n',' ');
fprintf(cif_file,'%s\n','data_VESTA_phase_1');
fprintf(cif_file,'%s\n',' ');
fprintf(cif_file,'%s\n',' ');
fprintf(cif_file,'%s\n','_chemical_name_common                 ''cube for volumetric potential energy d''');
fprintf(cif_file,'%s %s %018.15f\n','_cell_length_a','                       ',A);
fprintf(cif_file,'%s %s %018.15f\n','_cell_length_b','                       ',B);
fprintf(cif_file,'%s %s %018.15f\n','_cell_length_c','                       ',C);
fprintf(cif_file,'%s %s %018.15f\n','_cell_angle_alpha','                    ',angles(1));
fprintf(cif_file,'%s %s %018.15f\n','_cell_angle_beta','                     ',angles(2));
fprintf(cif_file,'%s %s %018.15f\n','_cell_angle_gamma','                    ',angles(3));
fprintf(cif_file,'%s %s %s\n','_space_group_name_H-M_alt','            ','''P 1''');
fprintf(cif_file,'%s %s %d\n','_symmetry_int_tables_number','           ',1);
fprintf(cif_file,'%s\n',' ')
fprintf(cif_file,'%s\n','loop_')
fprintf(cif_file,'%s\n','_space_group_symop_operation_xyz')
fprintf(cif_file,'%s\n','   ''x, y, z''')
fprintf(cif_file,'%s\n',' ')
fprintf(cif_file,'%s\n','loop_')
fprintf(cif_file,'%s\n','   _atom_site_label')
fprintf(cif_file,'%s\n','   _atom_site_occupancy')
fprintf(cif_file,'%s\n','   _atom_site_fract_x')
fprintf(cif_file,'%s\n','   _atom_site_fract_y')
fprintf(cif_file,'%s\n','   _atom_site_fract_z')
fprintf(cif_file,'%s\n','   _atom_site_adp_type')
fprintf(cif_file,'%s\n','   _atom_site_B_iso_or_equiv')
fprintf(cif_file,'%s\n','   _atom_site_type_symbol')
fprintf(cif_file,'%s\n',' ')

fclose(cif_file);
%%%%%%%%%

  SizeGrid_x=0.0;
  SizeGrid_y=0.0;
  SizeGrid_z=0.0;
  ShiftGrid_x=0.0;
  ShiftGrid_y=0.0;
  ShiftGrid_z=0.0;

  SizeGrid_x=SizeGrid_x+abs(cell_vector_SC(1,1));
  SizeGrid_y=SizeGrid_y+abs(cell_vector_SC(1,2));
  SizeGrid_z=SizeGrid_z+abs(cell_vector_SC(1,3));
  
  if(cell_vector_SC(1,1)<0.0) 
      ShiftGrid_x=ShiftGrid_x+cell_vector_SC(1,1);
  end
  if(cell_vector_SC(1,2)<0.0) 
      ShiftGrid_y=ShiftGrid_y+cell_vector_SC(1,2);
  end
  if(cell_vector_SC(1,3)<0.0) 
      ShiftGrid_z=ShiftGrid_z+cell_vector_SC(1,3);
  end

  SizeGrid_x=SizeGrid_x+abs(cell_vector_SC(2,1));
  SizeGrid_y=SizeGrid_y+abs(cell_vector_SC(2,2));
  SizeGrid_z=SizeGrid_z+abs(cell_vector_SC(2,3));
  
  if(cell_vector_SC(2,1)<0.0) 
      ShiftGrid_x=ShiftGrid_x+cell_vector_SC(2,1);
  end
  if(cell_vector_SC(2,2)<0.0) 
      ShiftGrid_y=ShiftGrid_y+cell_vector_SC(2,2);
  end
  if(cell_vector_SC(2,3)<0.0) 
      ShiftGrid_z=ShiftGrid_z+cell_vector_SC(2,3);
  end

  SizeGrid_x=SizeGrid_x+abs(cell_vector_SC(3,1));
  SizeGrid_y=SizeGrid_y+abs(cell_vector_SC(3,2));
  SizeGrid_z=SizeGrid_z+abs(cell_vector_SC(3,3));
  
  if(cell_vector_SC(3,1)<0.0) 
      ShiftGrid_x=ShiftGrid_x+cell_vector_SC(3,1);
  end
  if(cell_vector_SC(3,2)<0.0) 
      ShiftGrid_y=ShiftGrid_y+cell_vector_SC(3,2);
  end
  if(cell_vector_SC(3,3)<0.0) 
      ShiftGrid_z=ShiftGrid_z+cell_vector_SC(3,3);
  end
SizeGrid_x=SizeGrid_x%*supercell(1)
SizeGrid_y=SizeGrid_y%*supercell(2) 
SizeGrid_z=SizeGrid_z%*supercell(3)

ShiftGrid_x=ShiftGrid_x%*supercell(1)
ShiftGrid_y=ShiftGrid_y%*supercell(2) 
ShiftGrid_z=ShiftGrid_z%*supercell(3)

shift_file=fopen('shift.dat','w');                                                                                                                                                       
fprintf(shift_file,'%f %16f %16f',[ShiftGrid_x ShiftGrid_y ShiftGrid_z]);                                                                                                                                                          
fclose(shift_file);

cell_vector_SC_raspa=[SizeGrid_x 0 0; 0 SizeGrid_y 0; 0 0 SizeGrid_z];

abc_raspa_file=fopen('abc_raspa.dat','w');                                                                                                                                                       
fprintf(abc_raspa_file,'%f %16f %16f',[SizeGrid_x SizeGrid_y SizeGrid_z]);                                                                                                                                                          
fclose(abc_raspa_file);

ngrid_raspa=ceil([SizeGrid_x SizeGrid_y SizeGrid_z]./grid_size_raspa)

vtk_file=fopen('vtk_raspa_grid.dat','w');                                                                                                                                                       
fprintf(vtk_file,'%d',max(ngrid_raspa));                                                                                                                                                          
fclose(vtk_file);


E_matrix_raspa = 1e6*ones(ngrid_raspa(1),ngrid_raspa(2),ngrid_raspa(3));
%%%%convert grid data into matrices%%%%
ind=0;
n_doubles=0;
for x=1:ngrid(1)
    for y=1:ngrid(2)
        for z=1:ngrid(3)
            ind=ind+1;
            %row_ind=ceil(ind/6);
            %col_ind=ind-(row_ind-1)*6;
            E_matrix(x,y,z)=pot_data(ind);
            for nx=1:supercell(1)
                for ny=1:supercell(2)
                    for nz=1:supercell(3)
                        E_matrix(x+(nx-1)*ngrid(1),y+(ny-1)*ngrid(2),z+(nz-1)*ngrid(3))=pot_data(ind); 
                        frac_cube=[(x+(nx-1)*ngrid(1))/(ngrid(1)*supercell(1)) (y+(ny-1)*ngrid(2))/(ngrid(2)*supercell(2)) (z+(nz-1)*ngrid(3))/(ngrid(3)*supercell(3))];
                        cart_coords=frac_cube*cell_vector_SC+[ShiftGrid_x ShiftGrid_y ShiftGrid_z]*(-1);
                        igrid_raspa=ceil(cart_coords./grid_size_raspa);
                        
                        if E_matrix_raspa(igrid_raspa(1),igrid_raspa(2),igrid_raspa(3))==1000000
                            E_matrix_raspa(igrid_raspa(1),igrid_raspa(2),igrid_raspa(3))=pot_data(ind);
                            
                        else %take smallest value. Is average b
                            %mean_pot=R*T*log((exp(-E_matrix_raspa(igrid_raspa(1),igrid_raspa(2),igrid_raspa(3))*10/(R*T)) + exp(-pot_data(row_ind,col_ind)*10/(R*T)))/2)/10;
                            if E_matrix_raspa(igrid_raspa(1),igrid_raspa(2),igrid_raspa(3))>pot_data(ind)
                               %pot_data(row_ind,col_ind) 
                               %E_matrix_raspa(igrid_raspa(1),igrid_raspa(2),igrid_raspa(3))
                               n_doubles=n_doubles+1;
                               E_matrix_raspa(igrid_raspa(1),igrid_raspa(2),igrid_raspa(3))=pot_data(ind);
                            end
                        end
                    end
                end
            end
        end
    end
end


%ngrid_coarse=round(ngrid./ngrid_coarse);
%[E_matrix]=make_coarse(E_matrix,ngrid_coarse,ngrid,R,T);
%ngrid=ngrid_coarse;

min_value=min(min(pot_data));
pot_value_shifted=E_matrix-min_value;
pot_value_shifted_raspa=E_matrix_raspa-min_value;

grid2cube_raspa(pot_value_shifted,ngrid_SC,cell_vector_SC,'grid_SC.cube');

grid2cube_raspa(pot_value_shifted_raspa*100,ngrid_raspa,cell_vector_SC_raspa,'grid_raspa.cube')




