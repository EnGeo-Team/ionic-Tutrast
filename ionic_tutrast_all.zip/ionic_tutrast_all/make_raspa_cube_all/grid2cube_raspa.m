function grid2cube_raspa(grid,N,primvec,cube_out)

convAng2Bohr=1.889725989;
R=8.3144621;

%----------------------------
%print potential energy cube files
%----------------------------
disp('printing potential energy cube file....');
t3=cputime;
line=0;
cube_file=fopen(cube_out,'w');
fprintf(cube_file,'cube for volumetric potential energy data\n');
fprintf(cube_file,'--------------------------------\n');
fprintf(cube_file,'%d %8f %8f %8f\n',   1,    0.000000,    0.000000,    0.000000);
fprintf(cube_file,'%d %8f %8f %8f\n',N(1),primvec(1,1:3)*convAng2Bohr/N(1));
fprintf(cube_file,'%d %8f %8f %8f\n',N(2),primvec(2,1:3)*convAng2Bohr/N(2));
fprintf(cube_file,'%d %8f %8f %8f\n',N(3),primvec(3,1:3)*convAng2Bohr/N(3));
fprintf(cube_file,'%d %8f %8f %8f %8f\n',    1,    0.000000, 0.000000, 0.000000, 0.000000) 
%for iatom=1:cube.data(1,1)
%    fprintf(cube_file,'%d %8f %8f %8f %8f\n',cube.data(3+2*iatom,:),cube.data(3+2*iatom+1,1));
%end

grid_p = permute(grid,[3 2 1]);
grid_dat = reshape(grid_p,1,N(1)*N(2)*N(3));
fprintf(cube_file, '%f\n', grid_dat);

fclose(cube_file);

end
