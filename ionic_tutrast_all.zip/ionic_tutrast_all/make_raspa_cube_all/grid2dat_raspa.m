function grid2cube_raspa_fast(grid,N,primvec,cube_out)

convAng2Bohr=1.889725989;
R=8.3144621;

%----------------------------
%print potential energy cube files
%----------------------------
cube_file=fopen(cube_out,'w');
disp(cube_out);
t3=cputime;
line=0;

grid_p = permute(grid,[3 2 1]);
grid_dat = reshape(grid_p,1,N(1)*N(2)*N(3));
fprintf(cube_file, '%f\n', grid_dat);

fclose(cube_file);

end
