close all
clear all
%%%user defined%%%%%
E_unit=4;
LJ_cutoff=12.5;

Ecap=100000;
%%%read grid data%%%%%
disp('writing pot data...')

%Natoms=cube.data(1,1);
if E_unit==1 %kJ/mol
    conv=1;
elseif E_unit==2 %kcal/mol
    conv=4.184;
elseif E_unit==3 %Ry
    conv=1312.7497;
elseif E_unit==4 %eV
    conv=96.4853;
elseif E_unit==5 %Hartree
    conv=627.5096;
end
cube=importdata('grid_UC.cube');
symcube=importdata('syminfo.cube');
Natoms=cube.data(1,1);
pot_data=cube.data(2*Natoms+5:end,1)*conv;
pot_data(pot_data==Inf)=100000;
pot_data(pot_data>Ecap)=100000;
excl_vol=sum(pot_data==Ecap)/length(pot_data);

natoms=cube.data(1,1);
atoms=cube.data(5:2:5+2*natoms-1,1);
nLi_UC=load('nLi_UC.dat');

ngrid=[cube.data(2,1) cube.data(3,1) cube.data(4,1)];
ngrid_sym=[symcube.data(2,1) symcube.data(3,1) symcube.data(4,1)];
cell_data=cube.data(2:4,2:4)/1.8897259886;
symcell_data=symcube.data(2:4,2:4)/1.8897259886;
grid_size=[cell_data(1,1) cell_data(2,2) cell_data(3,3)];
grid_param=[sqrt(sum(cell_data(1,:).^2)) sqrt(sum(cell_data(2,:).^2)) sqrt(sum(cell_data(3,:).^2))];
grid_param_raspa=[cell_data(1,1) cell_data(2,2) cell_data(3,3)];
grid_param_vtk=[symcell_data(1,1) symcell_data(2,2) symcell_data(3,3)];

cell_vector_UC=[ngrid(1)*cell_data(1,:);ngrid(2)*cell_data(2,:);ngrid(3)*cell_data(3,:)];
a=sqrt(sum(cell_vector_UC(1,:).^2));
b=sqrt(sum(cell_vector_UC(2,:).^2));
c=sqrt(sum(cell_vector_UC(3,:).^2));
CosAlpha = max(min(real(dot(cell_vector_UC(2,:),cell_vector_UC(3,:)))/(norm(cell_vector_UC(2,:))*norm(cell_vector_UC(3,:))),1),-1);
CosBeta = max(min(real(dot(cell_vector_UC(1,:),cell_vector_UC(3,:)))/(norm(cell_vector_UC(1,:))*norm(cell_vector_UC(3,:))),1),-1);
CosGamma = max(min(real(dot(cell_vector_UC(1,:),cell_vector_UC(2,:)))/(norm(cell_vector_UC(1,:))*norm(cell_vector_UC(2,:))),1),-1);
alpha = acos(CosAlpha)*180/pi;
beta = acos(CosBeta)*180/pi;
gamma = acos(CosGamma)*180/pi;

supercell=ceil(2*LJ_cutoff./[cell_vector_UC(1,1) cell_vector_UC(2,2) cell_vector_UC(3,3)]);
cell_vector_SC=cell_vector_UC.*supercell';
A=a*supercell(1); B=b*supercell(2); C=c*supercell(3);

ngrid_SC=ngrid.*supercell;
ngrid_vtk=ngrid_sym.*supercell;
nLi_tot=nLi_UC*supercell(1)*supercell(2)*supercell(3);

format long
cell_vector_UC_file=fopen('cell_vector_UC.dat','w');
fprintf(cell_vector_UC_file,'%i %18f %18f %18f\n',ngrid(1),cell_vector_UC(1,:));
fprintf(cell_vector_UC_file,'%i %18f %18f %18f\n',ngrid(2),cell_vector_UC(2,:));
fprintf(cell_vector_UC_file,'%i %18f %18f %18f\n',ngrid(3),cell_vector_UC(3,:));
fclose(cell_vector_UC_file);

SC_file=fopen('supercell.dat','w');
fprintf(SC_file,'%d %8d %8d',   supercell);
fclose(SC_file);

nLi_file=fopen('nLi_SC.dat','w');
fprintf(nLi_file,'%d',   nLi_tot);
fclose(nLi_file);

vtk_file=fopen('ngrid_vtk.dat','w');
fprintf(vtk_file,'%i %8i %8i',   ngrid_vtk);
fclose(vtk_file);

%%%% make cif file
cif_file=fopen('grid.cif','w');
fprintf(cif_file,'%s\n','#=====================');
fprintf(cif_file,'%s\n',' ');
fprintf(cif_file,'%s\n','#CRYSTAL DATA');
fprintf(cif_file,'%s\n',' ');
fprintf(cif_file,'%s\n','#---------------------');
fprintf(cif_file,'%s\n',' ');
fprintf(cif_file,'%s\n','data_VESTA_phase_1');
fprintf(cif_file,'%s\n',' ');
fprintf(cif_file,'%s\n',' ');
fprintf(cif_file,'%s\n','_chemical_name_common                 ''cube for volumetric potential energy d''');
fprintf(cif_file,'%s %s %018.15f\n','_cell_length_a','                       ',A);
fprintf(cif_file,'%s %s %018.15f\n','_cell_length_b','                       ',B);
fprintf(cif_file,'%s %s %018.15f\n','_cell_length_c','                       ',C);
fprintf(cif_file,'%s %s %018.15f\n','_cell_angle_alpha','                    ',alpha);
fprintf(cif_file,'%s %s %018.15f\n','_cell_angle_beta','                     ',beta);
fprintf(cif_file,'%s %s %018.15f\n','_cell_angle_gamma','                    ',gamma);
fprintf(cif_file,'%s %s %s\n','_space_group_name_H-M_alt','            ','''P 1''');
fprintf(cif_file,'%s %s %d\n','_symmetry_int_tables_number','           ',1);
fprintf(cif_file,'%s\n',' ')
fprintf(cif_file,'%s\n','loop_')
fprintf(cif_file,'%s\n','_space_group_symop_operation_xyz')
fprintf(cif_file,'%s\n','   ''x, y, z''')
fprintf(cif_file,'%s\n',' ')
fprintf(cif_file,'%s\n','loop_')
fprintf(cif_file,'%s\n','   _atom_site_label')
fprintf(cif_file,'%s\n','   _atom_site_occupancy')
fprintf(cif_file,'%s\n','   _atom_site_fract_x')
fprintf(cif_file,'%s\n','   _atom_site_fract_y')
fprintf(cif_file,'%s\n','   _atom_site_fract_z')
fprintf(cif_file,'%s\n','   _atom_site_adp_type')
fprintf(cif_file,'%s\n','   _atom_site_B_iso_or_equiv')
fprintf(cif_file,'%s\n','   _atom_site_type_symbol')
fprintf(cif_file,'%s\n',' ')

fclose(cif_file);


  SizeGrid_x=0.0;
  SizeGrid_y=0.0;
  SizeGrid_z=0.0;
  ShiftGrid_x=0.0;
  ShiftGrid_y=0.0;
  ShiftGrid_z=0.0;

  SizeGrid_x=SizeGrid_x+abs(cell_vector_SC(1,1));
  SizeGrid_y=SizeGrid_y+abs(cell_vector_SC(1,2));
  SizeGrid_z=SizeGrid_z+abs(cell_vector_SC(1,3));
  
  if(cell_vector_SC(1,1)<0.0) 
      ShiftGrid_x=ShiftGrid_x+cell_vector_SC(1,1);
  end
  if(cell_vector_SC(1,2)<0.0) 
      ShiftGrid_y=ShiftGrid_y+cell_vector_SC(1,2);
  end
  if(cell_vector_SC(1,3)<0.0) 
      ShiftGrid_z=ShiftGrid_z+cell_vector_SC(1,3);
  end

  SizeGrid_x=SizeGrid_x+abs(cell_vector_SC(2,1));
  SizeGrid_y=SizeGrid_y+abs(cell_vector_SC(2,2));
  SizeGrid_z=SizeGrid_z+abs(cell_vector_SC(2,3));
  
  if(cell_vector_UC(2,1)<0.0) 
      ShiftGrid_x=ShiftGrid_x+cell_vector_SC(2,1);
  end
  if(cell_vector_UC(2,2)<0.0) 
      ShiftGrid_y=ShiftGrid_y+cell_vector_SC(2,2);
  end
  if(cell_vector_UC(2,3)<0.0) 
      ShiftGrid_z=ShiftGrid_z+cell_vector_SC(2,3);
  end

  SizeGrid_x=SizeGrid_x+abs(cell_vector_SC(3,1));
  SizeGrid_y=SizeGrid_y+abs(cell_vector_SC(3,2));
  SizeGrid_z=SizeGrid_z+abs(cell_vector_SC(3,3));
  
  if(cell_vector_SC(3,1)<0.0) 
      ShiftGrid_x=ShiftGrid_x+cell_vector_SC(3,1);
  end
  if(cell_vector_SC(3,2)<0.0) 
      ShiftGrid_y=ShiftGrid_y+cell_vector_SC(3,2);
  end
  if(cell_vector_SC(3,3)<0.0) 
      ShiftGrid_z=ShiftGrid_z+cell_vector_SC(3,3);
  end

ngrid_raspa=nearest([SizeGrid_x SizeGrid_y SizeGrid_z]./grid_param_raspa);
cell_vector_raspa=[SizeGrid_x 0 0; 0 SizeGrid_y 0; 0 0 SizeGrid_z];
cell_vector_raspa_file=fopen('cell_vector_raspa.dat','w');                                                                                                                                                       
fprintf(cell_vector_raspa_file,'%i %16f %16f %16f\n',ngrid_raspa(1),cell_vector_raspa(1,:));  
fprintf(cell_vector_raspa_file,'%i %16f %16f %16f\n',ngrid_raspa(2),cell_vector_raspa(2,:));   
fprintf(cell_vector_raspa_file,'%i %16f %16f %16f\n',ngrid_raspa(3),cell_vector_raspa(3,:));                                                                                                                                                          
fclose(cell_vector_raspa_file);

raspa_cell_file=fopen('raspa_cell.dat','w');
fprintf(raspa_cell_file,'%018.15f %018.15f %018.15f\n',A,B,C);
fprintf(raspa_cell_file,'%i %18i %18i\n',ShiftGrid_x,ShiftGrid_y,ShiftGrid_z);
fprintf(raspa_cell_file,'%i %18i %18i\n',ngrid_raspa(1)+1,ngrid_raspa(2)+1,ngrid_raspa(3)+1);
fprintf(raspa_cell_file,'%i %18i %18i\n',grid_size(1),grid_size(2),grid_size(3));
fclose(raspa_cell_file);

format short

%%%make E-matrix from cube data, make supercell%%%%

ind=0;
for x=1:ngrid(1)
    for y=1:ngrid(2)
        for z=1:ngrid(3)
            ind=ind+1;
            E_matrix(x,y,z)=pot_data(ind);
            for nx=1:supercell(1)
                for ny=1:supercell(2)
                    for nz=1:supercell(3)
                        E_matrix_SC(x+(nx-1)*ngrid(1),y+(ny-1)*ngrid(2),z+(nz-1)*ngrid(3))=pot_data(ind); 
                    end
                end
            end
        end
    end
end

%%%%fill raspa UC grid with values from cube SC%%%%

ind=0;
for x=1:ngrid_raspa(1)
    for y=1:ngrid_raspa(2)
        for z=1:ngrid_raspa(3)
            ind=ind+1;
            cart_coords=([x-1,y-1,z-1]./ngrid_raspa)*cell_vector_raspa;
            frac_coords_cube=(cart_coords+[ShiftGrid_x ShiftGrid_y ShiftGrid_z])/cell_vector_SC;
            igrid_cube=round(frac_coords_cube.*ngrid_SC-[ShiftGrid_x ShiftGrid_y ShiftGrid_z]./grid_param)+1;
            igrid_cube=igrid_cube-ngrid_SC.*floor((igrid_cube-1)./ngrid_SC); %wrap grid points
            E_matrix_raspa(x,y,z)=E_matrix_SC(igrid_cube(1),igrid_cube(2),igrid_cube(3));
        end
    end
end

pot_value_shifted_raspa=E_matrix_raspa-min(pot_data);
grid2cube_raspa(pot_value_shifted_raspa,ngrid_raspa,cell_vector_raspa,'E_grid_raspa.cube');

%%%%compute derivatives and put into supercell matrices%%%%

E_matrix_raspa_pad=E_matrix_raspa;
for x=1:ngrid_raspa(1)
    for y=1:ngrid_raspa(2)
        for z=1:ngrid_raspa(3)
            ind=ind+1;

            if x==ngrid_raspa(1)
                xp=1;
            else
                xp=x+1;
            end
            if x==1
                xm=ngrid_raspa(1);
            else
                xm=x-1;
            end
            if y==ngrid_raspa(2)
                yp=1;
            else
                yp=y+1;
            end
            if y==1
                ym=ngrid_raspa(2);
            else
                ym=y-1;
            end
            if z==ngrid_raspa(3)
                zp=1;
            else
                zp=z+1;
            end
            if z==1
                zm=ngrid_raspa(3);
            else
                zm=z-1;
            end

            Dx_matrix_raspa(x,y,z)=(E_matrix_raspa(xp,y,z)-E_matrix_raspa(xm,y,z))/2;%/grid_size(1);
            Dy_matrix_raspa(x,y,z)=(E_matrix_raspa(x,yp,z)-E_matrix_raspa(x,ym,z))/2;%/grid_size(2);
            Dz_matrix_raspa(x,y,z)=(E_matrix_raspa(x,y,zp)-E_matrix_raspa(x,y,zm))/2;%/grid_size(3);
            DDxy_matrix_raspa(x,y,z)=(E_matrix_raspa(xp,yp,z)-E_matrix_raspa(xm,yp,z)-E_matrix_raspa(xp,ym,z)+E_matrix_raspa(xm,ym,z))/4;%/grid_size(1)/grid_size(2);
            DDxz_matrix_raspa(x,y,z)=(E_matrix_raspa(xp,y,zp)-E_matrix_raspa(xm,y,zp)-E_matrix_raspa(xp,y,zm)+E_matrix_raspa(xm,y,zm))/4;%/grid_size(1)/grid_size(3);
            DDyz_matrix_raspa(x,y,z)=(E_matrix_raspa(x,yp,zp)-E_matrix_raspa(x,ym,zp)-E_matrix_raspa(x,yp,zm)+E_matrix_raspa(x,ym,zm))/4;%/grid_size(2)/grid_size(3);
            DDDxyz_matrix_raspa(x,y,z)=(E_matrix_raspa(xp,yp,zp)-E_matrix_raspa(xm,yp,zp)-E_matrix_raspa(xp,ym,zp)+E_matrix_raspa(xm,ym,zp)-E_matrix_raspa(xp,yp,zm)+E_matrix_raspa(xm,yp,zm)+E_matrix_raspa(xp,ym,zm)-E_matrix_raspa(xm,ym,zm))/8;%/grid_size(1)/grid_size(2)/grid_size(3);
            %{
            if E_matrix_raspa(xp,y,z)==100000
                E_matrix_raspa_pad(x,y,z)=100000;
            elseif E_matrix_raspa(x,yp,z)==100000
                E_matrix_raspa_pad(x,y,z)=100000;
            elseif E_matrix_raspa(x,y,zp)==100000
                E_matrix_raspa_pad(x,y,z)=100000;
            elseif E_matrix_raspa(xm,y,z)==100000
                E_matrix_raspa_pad(x,y,z)=100000;
            elseif E_matrix_raspa(x,ym,z)==100000
                E_matrix_raspa_pad(x,y,z)=100000;
            elseif E_matrix_raspa(x,y,zm)==100000
                E_matrix_raspa_pad(x,y,z)=100000;
            elseif E_matrix_raspa(xp,yp,z)==100000
                E_matrix_raspa_pad(x,y,z)=100000;
            elseif E_matrix_raspa(xp,y,zp)==100000
                E_matrix_raspa_pad(x,y,z)=100000;
            elseif E_matrix_raspa(xm,ym,z)==100000
                E_matrix_raspa_pad(x,y,z)=100000;
            elseif E_matrix_raspa(xm,y,zm)==100000
                E_matrix_raspa_pad(x,y,z)=100000;
            elseif E_matrix_raspa(x,ym,zm)==100000
                E_matrix_raspa_pad(x,y,z)=100000;
            elseif E_matrix_raspa(xp,ym,z)==100000
                E_matrix_raspa_pad(x,y,z)=100000;
            elseif E_matrix_raspa(xm,yp,z)==100000
                E_matrix_raspa_pad(x,y,z)=100000;
            elseif E_matrix_raspa(xp,yp,z)==100000
                E_matrix_raspa_pad(x,y,z)=100000;
            elseif E_matrix_raspa(xp,y,zm)==100000
                E_matrix_raspa_pad(x,y,z)=100000;
            elseif E_matrix_raspa(xm,y,zp)==100000
                E_matrix_raspa_pad(x,y,z)=100000;
            elseif E_matrix_raspa(x,yp,zm)==100000
                E_matrix_raspa_pad(x,y,z)=100000;
            elseif E_matrix_raspa(x,ym,zp)==100000
                E_matrix_raspa_pad(x,y,z)=100000;
            elseif E_matrix_raspa(xp,yp,zp)==100000
                E_matrix_raspa_pad(x,y,z)=100000;
            elseif E_matrix_raspa(xp,yp,zm)==100000
                E_matrix_raspa_pad(x,y,z)=100000;
            elseif E_matrix_raspa(xp,ym,zp)==100000
                E_matrix_raspa_pad(x,y,z)=100000;
            elseif E_matrix_raspa(xp,ym,zp)==100000
                E_matrix_raspa_pad(x,y,z)=100000;
            elseif E_matrix_raspa(xm,yp,zp)==100000
                E_matrix_raspa_pad(x,y,z)=100000;
            elseif E_matrix_raspa(xm,ym,zp)==100000
                E_matrix_raspa_pad(x,y,z)=100000;
            elseif E_matrix_raspa(xm,yp,zm)==100000
                E_matrix_raspa_pad(x,y,z)=100000;
            elseif E_matrix_raspa(xp,ym,zm)==100000
                E_matrix_raspa_pad(x,y,z)=100000;
            end
	      %}
       end
    end
end

%%%Add end points to raspa cube  E(ngrid_max)=E(0)%%%%
E_matrix_raspa_filled=E_matrix_raspa_pad;
x=ngrid_raspa(1)+1; %yz-layer
for y=1:ngrid_raspa(2)
    for z=1:ngrid_raspa(3)
        E_matrix_raspa_pad(x,y,z)=E_matrix_raspa_pad(1,y,z);
        Dx_matrix_raspa(x,y,z)=Dx_matrix_raspa(1,y,z);
        Dy_matrix_raspa(x,y,z)=Dy_matrix_raspa(1,y,z);
        Dz_matrix_raspa(x,y,z)=Dz_matrix_raspa(1,y,z);
        DDxy_matrix_raspa(x,y,z)=DDxy_matrix_raspa(1,y,z);
        DDyz_matrix_raspa(x,y,z)=DDyz_matrix_raspa(1,y,z);
        DDxz_matrix_raspa(x,y,z)=DDxz_matrix_raspa(1,y,z);
        DDDxyz_matrix_raspa(x,y,z)=DDDxyz_matrix_raspa(1,y,z);
    end
end

y=ngrid_raspa(2)+1; %xz-layer
for x=1:ngrid_raspa(1)+1
    for z=1:ngrid_raspa(3)
        E_matrix_raspa_pad(x,y,z)=E_matrix_raspa_pad(x,1,z);
        Dx_matrix_raspa(x,y,z)=Dx_matrix_raspa(x,1,z);
        Dy_matrix_raspa(x,y,z)=Dy_matrix_raspa(x,1,z);
        Dz_matrix_raspa(x,y,z)=Dz_matrix_raspa(x,1,z);
        DDxy_matrix_raspa(x,y,z)=DDxy_matrix_raspa(x,1,z);
        DDyz_matrix_raspa(x,y,z)=DDyz_matrix_raspa(x,1,z);
        DDxz_matrix_raspa(x,y,z)=DDxz_matrix_raspa(x,1,z);
        DDDxyz_matrix_raspa(x,y,z)=DDDxyz_matrix_raspa(x,1,z);
    end
end

z=ngrid_raspa(3)+1; %xy-layer
for x=1:ngrid_raspa(1)+1
    for y=1:ngrid_raspa(2)+1
        E_matrix_raspa_pad(x,y,z)=E_matrix_raspa_pad(x,y,1);
        Dx_matrix_raspa(x,y,z)=Dx_matrix_raspa(x,y,1);
        Dy_matrix_raspa(x,y,z)=Dy_matrix_raspa(x,y,1);
        Dz_matrix_raspa(x,y,z)=Dz_matrix_raspa(x,y,1);
        DDxy_matrix_raspa(x,y,z)=DDxy_matrix_raspa(x,y,1);
        DDyz_matrix_raspa(x,y,z)=DDyz_matrix_raspa(x,y,1);
        DDxz_matrix_raspa(x,y,z)=DDxz_matrix_raspa(x,y,1);
        DDDxyz_matrix_raspa(x,y,z)=DDDxyz_matrix_raspa(x,y,1);
    end
end


min_value=min(min(pot_data));
E_matrix_filled_shifted=E_matrix_raspa_filled-min_value;
E_matrix_raspa_shifted=E_matrix_raspa_pad-min_value;

%grid2cube_raspa(E_matrix_filled_shifted,ngrid_raspa,cell_vector_raspa,'E_grid_filled.cube');
%grid2cube_raspa(E_matrix_raspa_shifted*100,ngrid_raspa+1,cell_vector_raspa,'E_grid_raspa.cube')
grid2dat_raspa(E_matrix_raspa_shifted*100,ngrid_raspa+1,cell_vector_raspa,'E_grid_raspa.dat')
grid2dat_raspa(Dx_matrix_raspa*100,ngrid_raspa+1,cell_vector_raspa,'Dx_grid_raspa.dat')
grid2dat_raspa(Dy_matrix_raspa*100,ngrid_raspa+1,cell_vector_raspa,'Dy_grid_raspa.dat')
grid2dat_raspa(Dz_matrix_raspa*100,ngrid_raspa+1,cell_vector_raspa,'Dz_grid_raspa.dat')
grid2dat_raspa(DDxy_matrix_raspa*100,ngrid_raspa+1,cell_vector_raspa,'DDxy_grid_raspa.dat')
grid2dat_raspa(DDyz_matrix_raspa*100,ngrid_raspa+1,cell_vector_raspa,'DDyz_grid_raspa.dat')
grid2dat_raspa(DDxz_matrix_raspa*100,ngrid_raspa+1,cell_vector_raspa,'DDxz_grid_raspa.dat')
grid2dat_raspa(DDDxyz_matrix_raspa*100,ngrid_raspa+1,cell_vector_raspa,'DDDxyz_grid_raspa.dat')






