#! /bin/sh -f                                                                                             
#SBATCH -n 1                      
#SBATCH --time 1:00:00                
#SBATCH --job-name=make_raspa_cube_ortho
#SBATCH -A naiss2024-1-38                                
matlab -nodesktop -nojvm -r make_raspa_cube_all
