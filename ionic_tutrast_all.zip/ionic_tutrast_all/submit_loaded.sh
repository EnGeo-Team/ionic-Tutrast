#! /bin/sh -f 

structure_file="structure_list.dat"
read -p "Enter grid set name: " job
read -p "Enter ion charge (R for repeat, otherwise value): " charge
read -p "Enter code (identifier code for grid set): " code
read -p "Enter job id: " id

declare -i n=0

while read -r structure
do
    n=$n+1
    echo $n
    echo $structure  

    mkdir $structure/loaded_${job}_$id/
    rm /proj/teoroo/users/x_ambma/RASPA/share/raspa/grids/Local/grid/$n.$code/grid_Li_shifted.grid ## changes to correct path
    cp  $structure/make_raspa_cube_${job}/grid.raspa /proj/teoroo/users/x_ambma/RASPA/share/raspa/grids/Local/grid/$n.$code/grid_Li_shifted.grid # move vdw grid - change to correct path
    cp loaded/* $structure/loaded_${job}_$id/ ####
    cp $structure/make_raspa_cube_${job}/grid.cif $structure/loaded_${job}_$id/ ###
    cd $structure/loaded_${job}_$id/ ###
    SC=$(sed -n '1p' ../make_raspa_cube_${job}/supercell.dat)    
    vtk_grid=$(sed -n '1p' ../make_raspa_cube_${job}/ngrid_vtk.dat)    
    nLi=$(sed -n '1p' ../make_raspa_cube_${job}/nLi_SC.dat)

    qLi=$charge

    ##uncomment if using repeat charges (todo-add condition for R)
    #qLi=$(sed -n '1p' ../make_raspa_cube_${job}/charge.dat)        
    
    rm simulation.input

    echo 'SimulationType                   MonteCarlo' >simulation.input
    echo 'NumberOfCycles                   100000000' >> simulation.input
    echo 'NumberOfInitializationCycles     100000' >> simulation.input
    echo 'RestartFile                      no' >> simulation.input
    echo 'PrintEvery                       1000' >> simulation.input
    echo 'Forcefield                       Local' >> simulation.input
    #echo 'OmitAdsorbateAdsorbateVDWInteractions yes' >> simulation.input 
    echo ' ' >> simulation.input
    echo 'Framework 0' >> simulation.input
    echo 'FrameworkName grid' >> simulation.input
    echo 'RemoveAtomNumberCodeFromLabel yes' >> simulation.input
    echo 'UnitCells 1 1 1' >> simulation.input
    echo 'ExternalTemperature 1000.0' >> simulation.input
    echo 'ExternalPressure 10000.0' >> simulation.input
    echo 'EwaldPrecision 1e-5' >> simulation.input
    echo 'NumberOfGrids 1' >> simulation.input
    echo 'GridTypes Li' >> simulation.input
    echo 'SpacingCoulombGrid         ' $n.$code  >> simulation.input
    echo 'SpacingVDWGrid             ' $n.$code  >> simulation.input
    echo 'UseTabularGrid yes' >> simulation.input
    echo ' ' >> simulation.input
    echo 'ComputeDensityProfile3DVTKGrid yes' >> simulation.input
    echo 'WriteDensityProfile3DVTKGridEvery 10000' >> simulation.input
    echo 'DensityProfile3DVTKGridPoints  ' $vtk_grid   >> simulation.input
    echo ' ' >> simulation.input
    echo 'Component 0 MoleculeName                   Li' >> simulation.input
    echo '            MoleculeDefinition             Local' >> simulation.input
    echo '            TranslationProbability         1.0' >> simulation.input
    echo '            RandomTranslationProbability   1.0' >> simulation.input
    echo '            ExtraFrameworkMolecule         yes' >> simulation.input
    echo '            CreateNumberOfMolecules        '$nLi   >> simulation.input

    rm pseudo_atoms.def

    echo $qLi
    
    echo '#number of pseudo atoms' > pseudo_atoms.def
    echo '1' >> pseudo_atoms.def
    echo '#type      print   as    chem  oxidation   mass        charge   polarization B-factor radii' >> pseudo_atoms.def
    echo 'Li         yes     Li    Li    0           6.941       ' $qLi '   0.0          1.0      0.7     0            0           relative           0' >> pseudo_atoms.def



    
    rm slurm*
    sbatch run
    cd ../../
   

done < "$structure_file"
