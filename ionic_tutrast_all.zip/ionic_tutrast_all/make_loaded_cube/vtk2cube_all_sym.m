close all 
clear all

nO=1; %%%change this value to the computed loading for the respective pressure.
to_print=2; %1=density cube, 2=potential energy cube, 3=density dat, 4=potential energy dat, 5=potential energy xsf 
t1 = cputime;
T=1000;
vtk_data=readlines('DensityProfile_Li.vtk');
cube_out='grid.cube';
symcube=importdata('syminfo.cube');
convAng2Bohr=1.889725989;
R=8.3144621;

row2=split(vtk_data(2))';
cell_param=str2double(row2(2:7));
row5=split(vtk_data(5))';
ngrid_SC=str2double(row5(2:4));
row6=split(vtk_data(6))';
origin=str2double(row6(2:4));
row7=split(vtk_data(7))';
grid_size=str2double(row7(2:4));
row8=split(vtk_data(8))';
ndata=str2double(row8(2));
dens_data=str2double(split(vtk_data(11:10+ndata,1)));
ngrid_UC=[symcube.data(2,1) symcube.data(3,1) symcube.data(4,1)];
supercell=ngrid_SC./ngrid_UC;
sym_data=symcube.data(5:end,1);

%%make fractional coordinate list 
n=0;
dens_grid=zeros(ngrid_SC); 
for ix=1:ngrid_SC(1)
    for iy=1:ngrid_SC(2)
        for iz=1:ngrid_SC(3)
            n=n+1;
            row_dens=(ix-1)+(iy-1)*ngrid_SC(1)+(iz-1)*ngrid_SC(1)*ngrid_SC(2)+1;
            value_dens=dens_data(row_dens);
            dens_grid(ix,iy,iz)=value_dens;
            
        end
    end
end

dens_grid_UC=zeros(ngrid_UC);
for UC_x=1:supercell(1)
    for UC_y=1:supercell(2)
        for UC_z=1:supercell(3)
            for ix=1:ngrid_UC(1)
                for iy=1:ngrid_UC(2)
                    for iz=1:ngrid_UC(3)
                        n=n+1;
                        dens_grid_UC(ix,iy,iz)=dens_grid_UC(ix,iy,iz)+dens_grid(ix+(UC_x-1)*ngrid_UC(1),iy+(UC_y-1)*ngrid_UC(2),iz+(UC_z-1)*ngrid_UC(3));
                    end
                end
            end      
        end
    end
end

disp('done');									    
line=0;										    
for iA=1:ngrid_UC(1)									    
    for iB=1:ngrid_UC(2)									    
        for iC=1:ngrid_UC(3)								    
            line=line+1;								    
            dens_array(line)=dens_grid_UC(iA,iB,iC);					    
	 										    
        end										    
    end   										    
end

%Average denisities over equivalemnt symmetries
std_array=zeros(1,line);								    
for n_sym=1:max(sym_data)									    
    sym_sum=mean(dens_array(sym_data==n_sym));						    
    sym_std=std(dens_array(sym_data==n_sym));						    
    dens_array(sym_data==n_sym)=sym_sum;							    
    std_array(sym_data==n_sym)=sym_std;							    
end											    									    
										    
sum_grid_data=sum(sum(sum(dens_array))); %compute normalization factor						    
prob_data=(dens_array+1e-10)/sum_grid_data;	%normalize to probability					    
pot_array=-log((prob_data)/max(max(max(prob_data))))*T*R/1000; %Convert probabitity to potential energy and shift min to zero.			    
											    
%plot(pot_array,std_array./dens_array,'*')						    
											    
											    
%----------------------------								    
%print potential energy cube files							    
%----------------------------								    
disp('printing potential energy cube file....');					    
t3=cputime;										    
line=0;											    
cube_file=fopen(cube_out,'w');								    
fprintf(cube_file,'cube for volumetric potential energy data\n');			    
fprintf(cube_file,'--------------------------------\n');				    
fprintf(cube_file,'%d %8f %8f %8f\n',1,0.0000,0.0000,0.0000);				    
fprintf(cube_file,'%d %8f %8f %8f\n',ngrid_UC(1),symcube.data(2,2:4)*convAng2Bohr);		    
fprintf(cube_file,'%d %8f %8f %8f\n',ngrid_UC(2),symcube.data(3,2:4)*convAng2Bohr);		    
fprintf(cube_file,'%d %8f %8f %8f\n',ngrid_UC(3),symcube.data(4,2:4)*convAng2Bohr);		    
fprintf(cube_file,'%d %8f %8f %8f\n',1,0.0000,0.0000,0.0000);				    
											    								    
 for cube_line=1:length(pot_array)           						    
    fprintf(cube_file,'%f ',pot_array(cube_line));					    
	fprintf(cube_file,'\n');							    
 end											    
           										    
fclose(cube_file);									    
											    
											    
											    
disp('done');										    
											    
TuTraSt_Tall                                                                                            


