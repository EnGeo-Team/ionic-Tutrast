#! /bin/sh -f                                                                                             
#SBATCH -n 1                      
#SBATCH --time 02:00:00                
#SBATCH --job-name=run_TuTraSt
##SBATCH -A SOME_PROJECT
#SBATCH -A SOME_PROJECT
matlab -nodesktop -nojvm -r TuTraSt_Tall
