#! /bin/sh -f                                                                                             
#SBATCH -n 1                      
#SBATCH --time 01:00:00                
#SBATCH --job-name=make_loaded_cube
##SBATCH -A SOME_PROJECT
#SBATCH -A SOME_PROJECT
matlab -nodesktop -nojvm -r vtk2cube_ortho
