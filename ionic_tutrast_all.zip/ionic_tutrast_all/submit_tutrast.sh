#! /bin/sh -f 

module load MATLAB/2023a-bdist
read -p "Enter gs: " gs
read -p "Enter charge: " charge
#job='gs02'
#charge='1'
structure_file="list_FD_REPEAT.dat"
while read -r structure
do
    echo $structure
    mkdir $structure/tutrast_loaded_gs${gs}_q${charge}/
    cp $structure/make_loaded_cube_gs${gs}_q${charge}/loaded_grid.cube $structure/tutrast_loaded_gs${gs}_q${charge}/grid.cube
    cp -r tutrast/* $structure/tutrast_loaded_gs${gs}_q${charge}
    cd $structure/tutrast_loaded_gs${gs}_q${charge}/    
    rm slurm*
    rm D*
    rm basis*
    sbatch run_TuTraSt.sh
    cd ../../

done < "$structure_file"
