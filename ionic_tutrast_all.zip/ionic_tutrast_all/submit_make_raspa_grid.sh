#! /bin/sh -f
read -p "Enter grid set name: " job
read -p "Enter code: " code
declare -i n=0
structure_file="structure_list.dat"
while read -r structure
do
    n=$n+1
    echo $n
    echo $structure
    mkdir $structure/make_dummy_$job #make folder
    cp make_dummy/* $structure/make_dummy_$job #get run files
    cp $structure/make_raspa_cube_$job/grid.cif $structure/make_dummy_$job/
    cd $structure/make_dummy_$job/ # go to folder
     
    echo "SpacingVDWGrid          $n.$code" >> simulation.input #add lines to RASPA file
    echo "SpacingCoulombGrid      $n.$code" >> simulation.input
    echo "CutOffVDW               12.5" >> simulation.input
    rm slurm*
    rm -r /proj/teoroo/users/x_ambma/RASPA/share/raspa/grids/Local/grid/$n.$code
    sbatch run_dummy  #run

    cd ../..
    cp make_grid/* $structure/make_raspa_cube_$job/ 
    cd $structure/make_raspa_cube_$job/ # go to folder
    rm slurm*
    sbatch run_grid
    cd ../../

done < "$structure_file"
