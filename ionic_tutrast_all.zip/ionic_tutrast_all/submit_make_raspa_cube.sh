#! /bin/sh -f 

module load MATLAB/2023a-bdist
declare -i n=0
read -p "Name grid set: " job
structure_file="structure_list.dat"
while read -r structure
do
    n=$n+1
    echo $n
    echo $structure
    
    ####first time
    mkdir $structure/
    mkdir $structure/make_raspa_cube_$job
    sed "${n}q;d" nLi.dat > $structure/make_raspa_cube_$job/nLi_UC.dat
    sed "${n}q;d" charges.dat > $structure/make_raspa_cube_$job/charge.dat
    cp -r make_raspa_cube_all/* $structure/make_raspa_cube_$job/
    cp grids/*${structure}* $structure/make_raspa_cube_$job/grid_UC.cube
    cp Symmetry_Info_files/${structure}* ${structure}/make_raspa_cube_${job}/syminfo.cube

    cd $structure/make_raspa_cube_$job/
    sed -i -e 1,2d grid_UC.cube
    sed -i '1 i\---------' grid_UC.cube
    sed -i '1 i\cube file' grid_UC.cube
    sed -i -e 1,2d syminfo.cube
    sed -i '1 i\---------' syminfo.cube
    sed -i '1 i\sym file' syminfo.cube
    rm slurm*
    sbatch run_make_raspa_cube_all.sh
    cd ../../

done < "$structure_file"
